
using UnityEngine;

public class PlayerAnimation2 : MonoBehaviour
{
    [SerializeField] private Animator _animator;

    private void OnEnable()
    {
        //Player Controller
        PlayerController.OnStateChanged += HandleAnimation;
        
        //Player Movement
        Player_Movement.HasSideChanged += FlipSprite;
    }

    private void OnDisable()
    {
        //Player Controller
        PlayerController.OnStateChanged -= HandleAnimation;
        
        //Player Movement 
        Player_Movement.HasSideChanged -= FlipSprite;
    }
    
    private void Awake()
    {
        _animator = GetComponent<Animator>();
    }

    private void HandleAnimation(PlayerController.PlayerState state)
    {
        switch (state)
        {
            case PlayerController.PlayerState.Idle:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            case PlayerController.PlayerState.Walking:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            case PlayerController.PlayerState.Running:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            case PlayerController.PlayerState.Jumping:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            case PlayerController.PlayerState.Falling:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            case PlayerController.PlayerState.Attacking:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)state);
                break;
            default:
                _animator.SetInteger(StringsAnimation.CurrentState, (int)PlayerController.PlayerState.Idle);
                break;
        }
    }

    private void FlipSprite(bool isRightSide)
    {
        Vector3 scale = transform.localScale;
        if(isRightSide)
            scale.x = 1;
        else 
            scale.x = -1;
        transform.localScale = scale;
    }
    
}
